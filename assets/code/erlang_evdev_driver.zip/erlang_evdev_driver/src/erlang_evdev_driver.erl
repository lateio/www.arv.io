-module(erlang_evdev_driver).

-behavior(application).
-export([start/2,stop/1]).

-behavior(supervisor).
-export([init/1]).

%%====================================================================
%% API functions
%%====================================================================
start(_, _) ->
    supervisor:start_link(?MODULE, []).


stop(_) ->
    erl_ddll:unload("erlang_evdev_driver"),
    ok.


init([]) ->
    PrivDir = code:priv_dir(erlang_evdev_driver),
    ok = erl_ddll:load_driver(PrivDir, "erlang_evdev_driver"),
    {ok, {{rest_for_one, 0, 1}, []}}.

%%====================================================================
%% Internal functions
%%====================================================================
