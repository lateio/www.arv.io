erlang_evdev_driver
=====

An OTP library

Build
-----

    $ rebar3 compile
